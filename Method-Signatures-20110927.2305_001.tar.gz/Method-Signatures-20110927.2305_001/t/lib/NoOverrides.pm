# package for t/override_nothing.t

package NoOverrides;
use base qw< Method::Signatures >;


1;
